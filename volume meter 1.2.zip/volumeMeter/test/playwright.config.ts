import { chromium, defineConfig, devices } from "playwright/test";
import path from "path"; // <--- Alterado de "node:path" para "path" para maior compatibilidade
import { fileURLToPath } from 'url'; // <--- IMPORTANTE: Adicionado para corrigir o __dirname

// --- Correção para __dirname em Módulos ES ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// ---------------------------------------------

const dist = path.join(__dirname, "..", 'dist');

export default defineConfig({
    testDir: __dirname,
    reporter: [['list'], ["html", { outputFolder: 'playwright-report' }]],
    projects: [
        {
            name: "chromium-with-extension",
            use: {
                ...devices['desktop chrome'],
                headless: false,
                // O launchOptions foi REMOVIDO daqui de dentro
            },
            // CORREÇÃO: launchOptions deve ficar aqui, no mesmo nível do 'use'
            launchOptions: {
                args: [
                    `--disable-extensions-except=${dist}`,
                    `--load-extension=${dist}`
                ]
            }
        }
    ]
})